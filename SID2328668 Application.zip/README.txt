﻿---


## 2) Prerequisites


- **.NET SDK 8.0** (https://dotnet.microsoft.com/download)
- **XAMPP MySQL** running locally (default port 3306)
- **Visual Studio 2022** (or `dotnet` CLI)


---


## 3) Database Setup (MySQL / XAMPP)


1. Start **XAMPP** → **MySQL** (Start).
2. Open **phpMyAdmin** → create an empty database named **GrapheneTraceDB** (utf8mb4).
3. Import `/sql/GrapheneTraceDB_dump.sql`:
   - phpMyAdmin → select **GrapheneTraceDB** → **Import** → choose the file → **Go**.
4. Confirm key tables exist (e.g., `Users`, `PatientProfiles`, `ClinicianPatients`, `PatientDatasets`, `Frames`, `FrameMetrics`, `Alerts`).


> The database dump includes seeded accounts, 5 demo patient profiles, assignments, and ingested datasets/metrics.


---


## 4) Configure the app


Open `/src/Software_Engineering_2328668/appsettings.json` and check the MySQL connection string:


```json
"ConnectionStrings": {
  "Default": "Server=localhost;Port=3306;Database=GrapheneTraceDB;Uid=root;Pwd=;SslMode=None;CharSet=utf8mb4;"
}